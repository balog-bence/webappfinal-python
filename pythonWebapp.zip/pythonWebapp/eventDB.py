import sqlite3

con = sqlite3.connect("event.db")
print("Adatbazis eleres sikeres!")

con.execute(
    "create table Events (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT NOT NULL, date TEXT UNIQUE NOT NULL, city TEXT NOT NULL, venue TEXT NOT NULL, ticket TEXT NOT NULL)")

print("A tabla sikeresen letrehozva!")

con.close()
