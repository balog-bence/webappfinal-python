from flask import *
import json
import sqlite3
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route("/view")
def view():
    con = sqlite3.connect("event.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from Events")
    rows = cur.fetchall()
    return json.dumps([dict(ix) for ix in rows])

@app.route("/savedetails/", methods=["POST"])
def saveDetails():
    msg = "msg"
    try:
        data = request.get_json(force=True)
        print(data)
        event = data["event"]
        date = data["date"]
        city = data["city"]
        venue = data["venue"]
        ticket = data["ticket"]
        with sqlite3.connect("event.db") as con:
            cur = con.cursor()
            cur.execute("INSERT into Events (event, date, city, venue, ticket) values (?,?,?,?,?)", (event, date, city, venue, ticket))
            con.commit()
            msg = "Esemeny sikeresen hozzaadva!"
    except:
        con.rollback()
        msg = "Nem sikerult hozzaadni az esemenyt! :("
    finally:
        return ""
        con.close()

@app.route("/deleterecord/", methods=["POST"])
def deleterecord():
    data = request.get_json(force=True)
    id = str(data["id"])
    print(id)
    with sqlite3.connect("event.db") as con:
        try:
            cur = con.cursor()
            cur.execute("delete from Events where id = ?", id)
            msg = "Esemeny sikeresen torolve!"
        except:
            msg = "Az esemeny nem torolheto!"

@app.route("/updatedetails/", methods=["POST"])
def updaterecord():
    try:
        data = request.get_json(force=True)
        print(data)
        id = data["id"]
        event = data["event"]
        date = data["date"]
        city = data["city"]
        venue = data["venue"]
        ticket = data["ticket"]

        with sqlite3.connect("event.db") as con:
            cur = con.cursor()
            cur.execute("UPDATE Events SET event=?, date=?, city=?, venue=?, ticket=?, WHERE id=?", (event, date, city, venue, ticket, id))
            con.commit()
            msg = "Esemeny sikeresen frissitve!"
    except:
        con.rollback()
        msg = "Nem tudtuk frissiteni az esemenyt!"
    finally:
        return msg
        con.close()

if __name__ == "__main__":
    app.run(debug=True)
