function sendPost(){
    const data = JSON.stringify({
        Esemény:document.getElementById("event").value,
        Dátum:document.getElementById("date").value,
        Város:document.getElementById("city").value,
        Helyszín:document.getElementById("venue").value,
        Jegyár:document.getElementById("ticket").value
      });
      
      navigator.sendBeacon('http://127.0.0.1:5000/savedetails/', data);
      console.log(data);
      alert("Sikeresen hozzáadtál egy eseményt!")
    }