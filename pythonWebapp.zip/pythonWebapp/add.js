function sendPost(){
    const data = JSON.stringify({
        event:document.getElementById("event").value,
        date:document.getElementById("date").value,
        city:document.getElementById("city").value,
        venue:document.getElementById("venue").value,
        ticket:document.getElementById("ticket").value
      });
      
      navigator.sendBeacon('http://127.0.0.1:5000/savedetails/', data);
      console.log(data);
      alert("Sikeresen hozzáadtál egy eseményt!")
    }